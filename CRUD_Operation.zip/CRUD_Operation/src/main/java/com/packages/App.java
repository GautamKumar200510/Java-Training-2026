package com.packages;

 class App {
    public static void main( String[] args ){
       Employeedao empdao = new Employeedaoimpl();
       
       System.out.println("Create Record");
       empdao.createRecord();
       
       
       System.out.println("Update Record");
       empdao.updateRecord();
       
       System.out.println("Delete Reocrd");
       empdao.deleteRecord();
       
       System.out.println("Read Record");
       empdao.readRecord();
    	
    }
}
