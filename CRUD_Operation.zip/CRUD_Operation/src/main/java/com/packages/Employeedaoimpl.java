package com.packages;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class Employeedaoimpl implements Employeedao {
	
	private SessionFactory factory;

    public Employeedaoimpl() {
        factory = new Configuration()
                    .configure("hibernate.cfg.xml")
                    .addAnnotatedClass(Employee.class)
                    .buildSessionFactory();
    }
    
    public void createRecord() {
    	Session session = factory.openSession();
    	Transaction t1 = session.beginTransaction();
    	
    	
    	Employee emp = new Employee();
    	emp.setId(1);
    	emp.setName("Rai");
    	emp.setGender("Male");
    	
    	session.persist(emp);
    	t1.commit();
    	session.close();
    	
    	System.out.println("This is a create record");
    }
    
    public void updateRecord() {
    	Session session = factory.openSession();
    	Transaction t1 = session.beginTransaction();
    	
    	
    	
    	Employee emp = session.get(Employee.class,1);
    	if(emp!=null) {
    		emp.setGender("Femail");
    		session.update(emp);
    		System.out.println("Updates record");
    	}
    	t1.commit();
    	session.close();
    	
    }
    
    
    public void deleteRecord() {
    	Session session = factory.openSession();
    	Transaction t1 = session.beginTransaction();
    	
    	
    	Employee emp = session.get(Employee.class, 1);
    	if(emp!=null) {
    		session.delete(emp);
    		
    		System.out.println("Deleted data");
    		
    		
    	}
    	
    	t1.commit();
    	session.close();
    }
	
    public void readRecord() {
    	Session session = factory.openSession();
    	Transaction t1 = session.beginTransaction();
    	
    	
    	Employee emp = session.get(Employee.class,1);
    	if(emp!=null) {
    		System.out.println("Record read"+emp);
    		
    	}
    	
    	else {
    		System.out.println("no record ");
    	}
    	
    	session.close();
    			
    }

}
