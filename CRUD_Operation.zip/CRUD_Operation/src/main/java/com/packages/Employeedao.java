package com.packages;

public interface Employeedao {
	
	public void createRecord();
	
	public void updateRecord();
	
	public void deleteRecord();
	
	public void readRecord();

}
